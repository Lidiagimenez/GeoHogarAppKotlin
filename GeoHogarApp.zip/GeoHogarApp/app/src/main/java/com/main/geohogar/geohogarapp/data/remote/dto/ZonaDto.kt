package com.main.geohogar.geohogarapp.data.remote.dto

/*import com.google.gson.annotations.SerializedName

data class ZonaDto(
    @SerializedName("ID_zona") val idZona: Int,
    @SerializedName("zona") val zona: String,
    @SerializedName("estado") val estado: Boolean? = true,  // Por defecto true
    @SerializedName("createdAt") val createdAt: String? = null,
    @SerializedName("updatedAt") val updatedAt: String? = null
)*/