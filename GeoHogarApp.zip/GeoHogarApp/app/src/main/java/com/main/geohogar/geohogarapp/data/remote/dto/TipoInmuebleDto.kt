package com.main.geohogar.geohogarapp.data.remote.dto

import com.google.gson.annotations.SerializedName

/*data class TipoInmuebleResponseDto(
    @SerializedName("data") val data: List<TipoInmuebleDto>
)

data class TipoInmuebleDto(
    @SerializedName("ID_tipoinmueble") val idTipoInmueble: Int,
    @SerializedName("inmueble") val inmueble: String,
    @SerializedName("estado") val estado: Boolean,
    @SerializedName("createdAt") val createdAt: String,
    @SerializedName("updatedAt") val updatedAt: String
)*/