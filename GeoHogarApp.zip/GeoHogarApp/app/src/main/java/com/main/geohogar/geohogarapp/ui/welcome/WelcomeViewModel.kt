package com.main.geohogar.geohogarapp.ui.welcome

class WelcomeViewModel {
}